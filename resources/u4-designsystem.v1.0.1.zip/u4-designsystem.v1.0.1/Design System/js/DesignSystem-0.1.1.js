/**
 * Style range slider (Chrome doesn't allow :before and :after styling on range sliders)
 */
function HM_InputRange() {

    this.track_prefs = ['webkit-slider-runnable', 'moz-range', 'ms'];

    this.onInit = function(applyTo) {
        var self = this,
            n;

        for (n = 0; n < applyTo.length; n++) {
            applyTo[n].rangeStyle = document.createElement('style');
            document.body.appendChild(applyTo[n].rangeStyle);

            this.updateRangeValue(applyTo[n]);

            applyTo[n].addEventListener('input', function() {
                self.updateRangeValue(this);
            }, false);
        }
    };

    this.updateRangeValue = function(element) {
        element.rangeStyle.textContent = this.getTrackStyleStr(
            element.id,
            this.getValStr(element, element.value),
            this.track_prefs
        );
    };

    this.getTrackStyleStr = function(id, val, prefs) {
        var str = '',
            len = prefs.length;

        for (var i = 0; i < len; i++) {
            str += '#' + id + '::-' + prefs[i] + '-track{background-size:' + val + '}';
        }

        return str;
    };

    this.getValStr = function(el, p, i) {
        var min = el.min || 0,
            perc = (el.max) ? ~~(100 * (p - min) / (el.max - min)) : p,
            val = perc + '% 100%';

        return val;
    };
}

/**
 * Extends the input elements
 *
 *  - Wrap the original input element with a div
 *  - Extracts the placeholder
 *  - Creates the validation icon element
 *  - Adds placeholder and validation logic
 */
function HM_Input() {

    this.inputRootClass = '{root}{object}input';
    this.wrapperClass = '__wrap';
    this.borderClass = '__border';
    this.placeholderClass = '__placeholder';
    this.placeholderHiddenClass = 'is--hidden';
    this.validationIconClass = '__validation-icon';
    this.justRemovedClassSuffix = '-just-removed';
    this.validationClasses = ['is-error', 'is-warning', 'is-success', 'is-info'];
    this.validationAnimationTime = 250;


    this.onInit = function (applyTo) {
        var self = this;

        this.prepareClasses();

        [].forEach.call(applyTo, function (inputElement) {
            if (self.shouldApply(inputElement.type)) {
                var inputWrapper = self.wrapInputElement(inputElement);
                var placeholderElement;

                self.createInputBorderInto(inputWrapper);
                placeholderElement = self.createExternalPlaceholderInto(inputWrapper);
                self.createValidationIconFor(inputWrapper);

                self.setPlaceholderLogicRelatedTo(inputWrapper.input, placeholderElement);
                self.bindClassRemovalListenerTo(inputWrapper.input);
            }
        });
    };

    /**
     * Complete classes with the input root class
     */
    this.prepareClasses = function () {
        this.inputRootClass = HammeriteJS.replaceWithPrefixes(this.inputRootClass);
        this.wrapperClass = this.inputRootClass + this.wrapperClass;
        this.borderClass = this.inputRootClass + this.borderClass;
        this.placeholderClass = this.inputRootClass + this.placeholderClass;
        this.validationIconClass = this.inputRootClass + this.validationIconClass;
    };

    /**
     * tells if the modifications should be applied for this input type
     * @param  String   inputType
     * @return Boolean
     */
    this.shouldApply = function (inputType) {
        return  (inputType !== 'radio') &&
                (inputType !== 'checkbox');
    };

    /**
     * Creates a wrapper around the input element
     * @param  DOMElement   inputElement
     * @return DOMElement                   wrapper
     */
    this.wrapInputElement = function (inputElement) {
        var wrapper = document.createElement('div');
        var clonedInput = inputElement.cloneNode(true);
        wrapper.classList.add(this.wrapperClass);
        wrapper.appendChild(clonedInput);
        wrapper.input = clonedInput;
        inputElement.parentNode.replaceChild(wrapper, inputElement);
        return wrapper;
    };

    /**
     * create external input border (for motion)
     * @param  DOMElement   inputElement
     * @return DOMElement                   border
     */
    this.createInputBorderInto = function (inputWrapper) {
        var border = document.createElement('div');
        border.classList.add(this.borderClass);
        inputWrapper.appendChild(border);
        return border;
    };

    /**
     * Creates the external input placeholder
     * @param  DOMElement inputWrapper
     * @return DOMElement               placeholder element
     */
    this.createExternalPlaceholderInto = function (inputWrapper) {
        var placeholderDOMElement = document.createElement("div");
        placeholderDOMElement.classList.add(this.placeholderClass);
        inputWrapper.appendChild(placeholderDOMElement);
        return placeholderDOMElement;
    };

    /**
     * Adds placeholder hide/show logic
     * @param DOMElement    inputElement        Input
     * @param DOMElement    placeholderElement  Placeholder
     */
    this.setPlaceholderLogicRelatedTo = function (inputElement, placeholderElement) {
        var self = this,
            placeholderText;

        if (inputElement.attributes.placeholder) {
            placeholderText = inputElement.attributes.placeholder.value;
            inputElement.attributes.placeholder.value = '';
            placeholderElement.innerHTML = placeholderText;
        }

        inputElement.addEventListener('input', function (e) {
            self.showPlaceholderIfInputIsEmpty(inputElement, placeholderElement);
        });

        self.showPlaceholderIfInputIsEmpty(inputElement, placeholderElement);
    };

    /**
     * Show/Hide placeholder according to input value
     * @param  DOMELement inputElement
     * @param  DOMELement placeholderElement
     */
    this.showPlaceholderIfInputIsEmpty = function (inputElement, placeholderElement) {
        if (inputElement.value !== '') {
            placeholderElement.classList.add(this.placeholderHiddenClass);
        } else {
            placeholderElement.classList.remove(this.placeholderHiddenClass);
        }
    };

    /**
     * Creates the validation icon element
     * @param  DOMELement   inputWrapper    Related input wrapper
     */
    this.createValidationIconFor = function (inputWrapper) {
        var validationElement = document.createElement("div");
        validationElement.classList.add(this.validationIconClass);
        inputWrapper.appendChild(validationElement);
    };

    /**
     * Binds class modification listener to the input
     * @param  DOMELement   inputElement    Related input
     */
    this.bindClassRemovalListenerTo = function (inputElement) {
        var self = this;

        inputElement.classChangeObserver = new MutationObserver(function (changeRecords) { self.classRemovalListener(changeRecords); });
        inputElement.classChangeObserver.observe(inputElement, { attributes: true, attributeOldValue: true, attributeFilter: ['class'] });
    };

    /**
     * Implements the class removal listener
     * @param   changeRecords   Observer change records
     */
    this.classRemovalListener = function (changeRecords) {
        var self = this;

        changeRecords.forEach(function (record) {
            var oldClass = record.oldValue;
            var newClass = record.target.attributes['class'].value;

            if (oldClass.length > newClass.length) {
                var removedClasses = self.classesRemoved(oldClass, newClass);
                var removedValidationClass;
                var justRemovedClass;

                removedClasses.forEach(function (removedClass) {
                    if (self.validationClasses.indexOf(removedClass) !== -1) {
                        removedValidationClass = removedClass;
                    }
                });

                if (removedValidationClass.length > 0) {
                    self.transformToJustRemoved(record.target, removedClasses, removedValidationClass);
                }
            }
        });
    };

    /**
     * Add the 'just removed' class to the input, and creates a timeout for the final removal
     * @param  DOMELement   target                  target input
     * @param  array        removedClasses          classes just removed
     * @param  string       removedValidationClass  validation class just removed
     */
    this.transformToJustRemoved = function (target, removedClasses, removedValidationClass) {
        var self = this,
            justRemovedClass = removedValidationClass + self.justRemovedClassSuffix;

        if (removedClasses.indexOf(justRemovedClass) == -1) {
            target.classList.add(justRemovedClass);
            target.classList.add(removedValidationClass);
            target.classChangeObserver.disconnect();

            setTimeout(function () {
                self.removeDefinitely(target, removedValidationClass);
                self.bindClassRemovalListenerTo(target);
            }, self.validationAnimationTime);
        }
    };

    /**
     * Remove all the validation classes at the end of the animation
     * @param  DOMELement   target                  target input
     * @param  string       removedValidationClass  validation class just removed
     */
    this.removeDefinitely = function (target, removedValidationClass) {
        var justRemovedClass = removedValidationClass + this.justRemovedClassSuffix;

        target.classList.remove(justRemovedClass);
        target.classList.remove(removedValidationClass);
    };

    /**
     * Retrieve the removed classes
     * @param  string   previousClassesStr  previous class attribute contents
     * @param  string   currentClassesStr   current class attribute contents
     * @return array                        removed classes
     */
    this.classesRemoved = function (previousClassesStr, currentClassesStr) {
        var previousClasses = previousClassesStr.split(' ');
        var currentClasses = currentClassesStr.split(' ');

        return previousClasses.filter(function (x) { return currentClasses.indexOf(x) == -1; });
    };
}
/**
 * Handles the custom combobox DOM elements creation
 */
var HM_Select_DOMCreation = {

	CSSClasses: {
		select:           ['o-select'],
		field: 		      ['o-select__field'],
        fieldBorder:      ['o-select__field-border'],
		trigger: 	      ['o-select__trigger'],
		menu: 		      ['c-menu','c-menu--limited'],
        menuItem:         ['c-menu__item']
	},

    /**
     * creates a new custom select related to the original one
     * @param  HTMLElement 	originalSelect
     * @return HTMLElement
     */
    createCustomSelectFrom: function (originalSelect) {
    	var select = this.createDOMElement('div', this.CSSClasses.select, {
    		'aria-atomic': 	'true',
        	'role':			'application'
    		}),
    		field = this.createField(originalSelect),
    		trigger =this.createTrigger(),
            selectID = originalSelect.id;

    	select.appendChild(field);
        select.appendChild(this.createDOMElement('div', this.CSSClasses.fieldBorder));
    	select.appendChild(trigger);
    	select.relatedOriginalSelect = originalSelect;
    	select.fieldChild = field;
    	select.triggerChild = trigger;

    	originalSelect.parentElement.insertBefore(select, originalSelect);

        if (selectID) {
            originalSelect.id = selectID + '_original';
            field.id = selectID;
        }

    	return select;
    },

    /**
     * creates the select field
     * @param  HTMLElement 	originalSelect
     * @return HTMLElement
     */
    createField: function (originalSelect) {
    	var field = this.createDOMElement('input', this.CSSClasses.field, {
    		'type'			: 'text',
    		'role'			: 'combobox',
    		'readonly'		: 'true',
    		'aria-readonly'	: 'false',
    		'tabindex'		: originalSelect.tabIndex
    	});

    	return field;
    },

    /**
     * creates the select trigger button
     * @return HTMLElement
     */
    createTrigger: function () {
        var trigger = this.createDOMElement('button', this.CSSClasses.trigger, {
        	'aria-hidden' 		: 	'true',
        	'tabIndex'			:   '-1'
        });

        return trigger;
    },

	/**
	 * creates all the DOM for the select options menus
	 * @param  HTMLElement originalSelect
	 * @return HTMLElement
	 */
    createCustomMenuFrom: function (originalSelect) {
    	var list = this.createDOMElement('ul', this.CSSClasses.menu, {
	    		'role' 			: 'listbox',
	        	'aria-expanded' : 'false'
	    	}),
    		n,
    		label,
    		menuItem,
    		itemAnchor;

 		for (order = 0; order < originalSelect.options.length; order ++) {
 			label = originalSelect.options[order].text;
 			menuItem = this.createDOMElement('li', this.CSSClasses.menuItem);
 			itemAnchor = this.createDOMElement('a', [], {
 				href		: '#' + order,
 				title 		: label,
 				tabindex 	: '-1'
 			});

 			itemAnchor.appendChild(document.createTextNode(label));
 			menuItem.appendChild(itemAnchor);
            list.appendChild(menuItem);
		}

        list.style.minWidth = originalSelect.offsetWidth + 'px';
        document.body.appendChild(list);

    	return list;
    },

    /**
     * returns a new DOM Element
     * @param  String 	tagType    	new element HTML tag type (div, a,...)
     * @param  Array 	classes    	(optional) append css classes to element
     * @param  Object 	attributes 	(optional) HTML attributes { attribute: 'value', ...}
     * @return HTMLElement 			new HTML element
     */
    createDOMElement: function (tagType, classes, attributes) {
    	var element = document.createElement(tagType);

    	if ((typeof classes === 'object') && (classes.length > 0)) {
    		[].forEach.call(classes, function (elementClass) {
    			element.classList.add(elementClass);
    		});
    	}

        this.assignAttributes(element, attributes);

    	return element;
    },

    /**
     * sets attributes using an object
     * @param  HTMLElement  element
     * @param  Object       attributes  HTML attributes { attribute: 'value', ...}
     */
    assignAttributes: function (element, attributes) {
        if (typeof attributes === 'object') {
            Object.keys(attributes).forEach(function (attribute) {
                element.setAttribute(attribute, attributes[attribute]);
            });
        }
    },

    /**
     * sets style properties using an object
     * @param  HTMLElement  element
     * @param  Object       properties  JS CSS properties { property: 'value', ...}
     */
    assignStyleProperties: function (element, properties) {
        if (typeof properties === 'object') {
            Object.keys(properties).forEach(function (property) {
                element.style[property] = properties[property];
            });
        }
    }

};
/**
 * Handles the menu list option selection
 */
var HM_Select_Option = {
    searchTimeLimit: 0.7,
	optionSelectedClass: 'is--selected',

    /**
     * finds and select an option using keystrokes
     * @param  char         charCode
     * @param  HTMLElement  select
     */
    find: function (charCode, select) {
        this._addToSearchBuffer(charCode, select);

        index = this.searchOption(select.searchBuffer, select.originalSelect);

        if (index !== -1) {
            this.moveSelectionTo(index, select);
        }
    },

    /**
     * searchs for an option
     * @param  String       searchTerm
     * @param  HTMLElement  select
     * @return int          option index, -1 if not found
     */
    searchOption: function (searchTerm, select) {
        var found = false,
            bufferLen = searchTerm.length,
            optionText,
            n = 0;

        while (!found && n < select.options.length) {
            optionText = select.options[n].text;
            if (optionText.substr(0, bufferLen) === searchTerm) {
                found = true;
            } else {
                n++;
            }
        }

        return (found ? n : -1);
    },

    /**
     * removes the selected class for all the items
     * @param  HTMLElement menu
     */
    deselectAll: function (menu) {
        var self = this;

        [].forEach.call(menu.querySelectorAll('li'), function (menuItem) {
            menuItem.classList.remove(self.optionSelectedClass);
        });
    },

    /**
     * moves the selection to option #order
     * @param  int          order
     * @param  HTMLElement  select
     */
    moveSelectionTo: function (order, select) {
        var optionItem = select.menu.querySelectorAll('li')[order];
        if (optionItem) {
            select.originalSelect.selectedIndex = order;
            select.fieldChild.value = select.originalSelect.options[order].text;
            this.deselectAll(select.menu);
            optionItem.classList.add(this.optionSelectedClass);
            this.scrollMenuIfNeeded(select);
        }
    },

    /**
     * selects previous option
     * @param  HTMLElement  select
     */
    moveSelectionToPrev: function (select) {
        var order = select.originalSelect.selectedIndex - 1;

        if (order > -1) {
            this.moveSelectionTo(order, select);
        }
    },

    /**
     * selects next option
     * @param  HTMLElement  select
     */
    moveSelectionToNext: function (select) {
        var order = select.originalSelect.selectedIndex + 1;

        if (order < select.originalSelect.options.length) {
            this.moveSelectionTo(order, select);
        }
    },

    /**
     * changes menu scroll if selected element is not visible
     * @param  HTMLElement  select
     * @param  boolean      scrollToCenter (optional) if true, centers the item into the visible part
     */
    scrollMenuIfNeeded: function (select, scrollToCenter) {
        var topScroll = select.menu.scrollTop,
            menuHeight = select.menu.offsetHeight,
            visiblePart = topScroll + menuHeight,
            selectedItem =  select.menu.querySelector('li.' + this.optionSelectedClass),
            selectedItemPositionTop = selectedItem.offsetTop,
            selectedItemHeight = selectedItem.offsetHeight,
            selectedItemPositionBottom = selectedItemPositionTop + selectedItemHeight;

        if ((typeof scrollToCenter === 'boolean') && scrollToCenter) {

            if ((selectedItemPositionBottom > visiblePart) || (selectedItemPositionTop < topScroll)) {
                select.menu.scrollTop = selectedItemPositionTop - Math.floor(menuHeight / 2);
            }

        } else {
            if (selectedItemPositionBottom > visiblePart) {
                select.menu.scrollTop = topScroll + selectedItemHeight;
            }

            if (selectedItemPositionTop < topScroll) {
                select.menu.scrollTop = selectedItemPositionTop;
            }
        }
    },

    /**
     * adds a new char to the search buffer
     * @param  char         charCode
     * @param  HTMLElement  select
     */
    _addToSearchBuffer: function (charCode, select) {
        if (this._searchTimeExceeded(select.lastTimeTyped)) {
            select.searchBuffer = '';
        }

        select.searchBuffer += String.fromCharCode(charCode);
        select.lastTimeTyped = new Date().getTime();

    },

    /**
     * Tells if the time between keystrokes is over the limit
     * @param  int      lastTimeTyped
     * @return boolean
     */
    _searchTimeExceeded: function (lastTimeTyped) {
        var mSecondsLimit = this.searchTimeLimit * 1000,
            currentTime = new Date().getTime();

        return ((currentTime - lastTimeTyped) > mSecondsLimit);
    }
};
/**
 * Replaces browser native select menu
 */
function HM_Select() {
	this.optionSelectedClass = 'is--selected';
 	// Key codes
    this.KEY_ARROW_UP = 38;
    this.KEY_ARROW_DOWN = 40;
    this.KEY_ENTER = 13;
    this.KEY_SPACEBAR = 32;
    this.KEY_SCAPE = 27;

	this.onInit = function (applyTo) {
        var self = this,
        	select,
        	menu;

        [].forEach.call(applyTo, function (originalSelect) {
           select = HM_Select_DOMCreation.createCustomSelectFrom(originalSelect);
           menu = HM_Select_DOMCreation.createCustomMenuFrom(originalSelect);

           select.originalSelect = originalSelect;
           select.menu = menu;

           self.showSelectedValue(select);
           self.hideOriginal(originalSelect);
           self.handleEvents(select);
        });
    };

    /**
     * hides original select
     * @param  HTMLElement select
     */
    this.hideOriginal = function (select) {
 		select.setAttribute('aria-hidden', 'true');
        select.tabIndex = -1;
        HM_Select_DOMCreation.assignStyleProperties(select, {
        	border 				: '0px',
	        margin 				: '0px',
	        height 				: '1px',     // Safari fix
	        marginTop 			: '-1px',
	        padding 			: '0px',
	        webkitAppearance 	: 'none',  // Another Safari fix
	        display 			: 'block' // IE10 fix
        });
    };

    /**
     * handle the behaviour of the custom select via events
     *
     * - options menu appearance
     * - click on list item
     * - options selection
     *
     * @param  HTMLElement select
     */
    this.handleEvents = function (select) {
		this.handleMenuOptionsAppearance(select);
		this.handleClickOnListItem(select);
		this.handleOptionSelection(select);
    };

    /**
     * controls the events which cause the menu to appear/disappear
     * @param  HTMLElement select
     */
    this.handleMenuOptionsAppearance = function (select) {
    	var self = this;

		select.overlayMenuModule = new HM_OverlayMenu();
		select.overlayMenuModule.bindEvents(select.fieldChild, select.menu);

		// Override hide on blur function
		select.overlayMenuModule.isBlurTargetOutside = function (target, menu, handler) {
	        var targetGrandParent = target.parentElement;

	        if (targetGrandParent) {
	            targetGrandParent = targetGrandParent.parentElement;
	        }

	        return ((target !== handler) && (targetGrandParent !== menu) && (target !== select.triggerChild));
	    };

	    // Override menu toggle in order to scroll to selected element
	    select.overlayMenuModule.toggle = function (menu, handler) {
            select.fieldChild.focus();
        	this.positionMenu(menu, handler);
            menu.style.minWidth = select.fieldChild.offsetWidth + 'px';
        	menu.setAttribute('aria-expanded', menu.classList.toggle(this.menuOpenedClass));
        	HM_Select_Option.scrollMenuIfNeeded(select, true);
    	};


    	select.triggerChild.addEventListener('click', function (event) {
    		event.preventDefault();
    		select.overlayMenuModule.toggle(select.menu, select.fieldChild);
    	});

    	select.fieldChild.addEventListener('keydown', function (event) {
    		if 	(event.keyCode === self.KEY_SPACEBAR) {
    			event.preventDefault();
	        	HM_Select_Option.scrollMenuIfNeeded(select, true);
    			select.overlayMenuModule.open(select.menu, select.fieldChild);
    		} else if (event.keyCode === self.KEY_SCAPE) {
    			select.overlayMenuModule.close(select.menu, select.fieldChild);
    		}
    	});
    };

    /**
     * controls the menu items click event
     * @param  HTMLElement select
     */
    this.handleClickOnListItem = function (select) {
    	var self = this;

    	[].forEach.call(select.menu.querySelectorAll('a'), function (menuLink) {
            menuLink.addEventListener('click', function (event) {
            	event.preventDefault();
            	select.originalSelect.selectedIndex = self._getOrderFormLink(this);
            	self.showSelectedValue(select);
            	HM_Select_Option.moveSelectionTo(select.originalSelect.selectedIndex, select);
            	select.overlayMenuModule.toggle(select.menu, select);
            });
        });
    };

    /**
     * handles all the events related to options menu item selection
     * @param  HTMLElement select
     */
	this.handleOptionSelection = function (select) {
		var self = this;

		select.previousSelection = null;
		select.searchBuffer = '';
		select.lastTimeType = 0;

		select.fieldChild.addEventListener('keydown', function (event) {
    		if 	(event.keyCode === self.KEY_ARROW_UP) {
    			event.preventDefault();
    			HM_Select_Option.moveSelectionToPrev(select);
    			self.showSelectedValue(select);

    		} else if (event.keyCode === self.KEY_ARROW_DOWN) {
    			event.preventDefault();
				HM_Select_Option.moveSelectionToNext(select);
				self.showSelectedValue(select);
    		} else {
    			HM_Select_Option.find(event.keyCode, select);
    		}
		});

		if (select.originalSelect.selectedIndex > -1) {
			HM_Select_Option.moveSelectionTo(select.originalSelect.selectedIndex, select);
		}
	};

    /**
     * copies the original select selected value to the new custom
     * @param  HTMLElement select
     */
    this.showSelectedValue = function (select) {
    	var index = select.originalSelect.selectedIndex;

    	if (index > -1) {
        	select.fieldChild.value = select.originalSelect.options[index].text;
        }
	};

	/**
	 * extract the option order from a menu link
	 * @param  HTMLElement linkElement
	 * @return int             			option number
	 */
	this._getOrderFormLink = function (linkElement) {
        return parseInt(linkElement.href.split('#').pop(), 10);
    };


}
/*global window,document */


var HammeriteConfig = {
    'class-prefixes': {
        'root'      :   '',
        'helper'    :   'h-',
        'layout'    :   'l-',
        'object'    :   'o-',
        'component' :   'c-',
        'theming'   :   't-',
        'js-hooks'  :   'js-is-'
    },

    'self-name'     : 'designsystem',
    'sprite-path'   : '../images/icons/designsystem-sprite.svg'
};

/**
 * Add any JS module here.
 * Format: <module_name> : <apply to CSS selector>
 * @type {Object}
 */
var HammeriteModules = {
    'Input'                 :   '.{root}{object}input',
    'InputRange'            :   'input[type=range]',
    'EditableTableFocus'    :   '.{root}{component}table--editable .{root}{component}table--editable__input',
    'TextareaAutoheight'    :   'textarea[auto-resize]',
    'TextareaCounter'       :   'textarea[data-maxchars]',
    'Sidebar'               :   '.{root}{component}sidebar',
    'Tabs'                  :   '.{root}{component}tabs',
    'TabsSwipe'             :   '.{root}{component}tabs--fixed',
    'Icons'                 :   '.{root}{object}icon',
    'TopbarSearch'          :   '.{root}{component}topbar__toolbar',
    'OverlayMenu'           :   '[data-handler-for-menu]',
    'Select'                :   '.{root}{object}input--select:not([multiple])',
    'LabelFocus'            :   '.{root}{object}input,.{root}{object}select__field'
};

/**
 * Wrapper for all modules
 * @type {Object}
 */
var HammeriteJS = {
    modules: {},
    globalListeners: {
        resize: []
    },

    init: function () {
        this.getSelfURL();
        this.initModules(HammeriteModules);
        this.bindGlobalListeners();
    },

    getSelfURL: function () {
        var self = this,
            scriptCalls = document.querySelectorAll('script');

        [].forEach.call(scriptCalls, function (scriptCall) {
            var scriptURL = scriptCall.src;

            if (scriptURL.toLowerCase().indexOf(HammeriteConfig['self-name']) !== -1) {
                self.URL = scriptURL.split('/').slice(0, -1).join('/') + '/';
            }
        });
    },

    initModules: function (modules) {
        var module;

        for (module in modules) {
            this.initIfPresent('HM_' + module, modules[module]);
        }
    },

    initIfPresent: function (moduleClass, cssSelector) {
        cssSelector = this.replaceWithPrefixes(cssSelector);
        var foundElements = document.querySelectorAll(cssSelector);

        if (foundElements.length > 0) {
            this.initModule(moduleClass, foundElements);
        }
    },

    initModule: function (moduleClass, applyToElements) {
        var moduleInstance;

        if (!this.modules[moduleClass]) {
            moduleInstance = new window[moduleClass]();
            moduleInstance.onInit(applyToElements);

            this.registerListenersForModule(moduleInstance);

            this.modules[moduleClass] = moduleInstance;
        }
    },

    registerListenersForModule: function (moduleInstance) {
        var event,
            eventName;

        for (event in this.globalListeners) {
            eventName = 'on' + event[0].toUpperCase() + event.substr(1);

            if (moduleInstance[eventName]) {

                this.globalListeners[event].push(function () {
                    moduleInstance[eventName]();
                });
            }
        }
    },

    bindGlobalListeners: function () {
        var self = this,
                event;

        for (event in this.globalListeners) {
            window.addEventListener(event, function () {
                    self.globalListeners[event].forEach(function (eventHandler) {
                        eventHandler();
                    });
            });
        }
    },

    replaceWithPrefixes: function (className) {
        var matches = className.match(/\{([^\}]+)\}/g);

        if (matches) {
            matches.forEach(function (match) {
                var prefixname = match.replace(/\{|\}/g, '');

                if (HammeriteConfig['class-prefixes'][prefixname] !== undefined) {
                    className = className.replace(match, HammeriteConfig['class-prefixes'][prefixname]);
                }
            });
        }

        return className;
    }

};

/**
 * Bootstrap
 */
window.addEventListener('DOMContentLoaded', function () {

    HammeriteJS.init();

});

/**
 * Async icons SVG sprite loading
 */
function HM_Icons() {
    this.spriteAdded = false;
    this.spritePath;

    this.onInit = function (applyTo) {
        var self = this;
        if (!this.spriteAdded) {
            this.spritePath = HammeriteConfig['sprite-path'];
            this.loadSVGSprite(function (spriteContent) {
                self.addSpriteToDOM(spriteContent);
                self.spriteAdded = true;
            });
        }
    };

    /**
   	 * Loads SVG sprite asynchronously
   	 * @param  function loadCallBack
   	 */
    this.loadSVGSprite = function (loadCallBack) {
        var spriteURL = HammeriteJS.URL + this.spritePath,
            ajaxCall = new XMLHttpRequest();

        ajaxCall.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    loadCallBack(ajaxCall.responseText);
                } else {
                    console.error('Unable to load SVG icons sprite.' +
                        ' Please refer http://ux.unit4.com/designsystem/ for more information.' + 
                        ' SVG icons sprite expected to be in ' + spriteURL);
                }
            }
        };

        ajaxCall.open('GET', spriteURL, true);
        ajaxCall.send();
    };

    /**
   	 * adds a new DOM element for the SVG sprite
   	 * @param string spriteContent SVG sprite content
   	 */
    this.addSpriteToDOM = function (spriteContent) {
        var newDOMElement = document.createElement('div');
        newDOMElement.innerHTML = spriteContent;
        newDOMElement.style.display = 'none';
        document.body.insertBefore(newDOMElement, document.body.childNodes[0]);
    };

}
/**
 * Highlights the field label on focus
 */
function HM_LabelFocus() {
    this.activeLabelClassName = '{root}{object}label--focus';

    this.onInit = function (applyTo) {
        var self = this;

        self.activeLabelClassName = HammeriteJS.replaceWithPrefixes(self.activeLabelClassName);

        [].forEach.call(applyTo, function (labelElement) {
            var myLabel = self.findMyLabel(labelElement);

            if (myLabel) {
                var elementType = labelElement.type;
                var typeClassName = self.activeLabelClassName.replace('focus', 'for-' + elementType);
                myLabel.classList.add(typeClassName);

                labelElement.addEventListener('focus', function () {
                    myLabel.classList.add(self.activeLabelClassName);
                });

                labelElement.addEventListener('blur', function () {
                    myLabel.classList.remove(self.activeLabelClassName);
                });
            }
        });

    };

    this.findMyLabel = function (inputObj) {
        var label,
            forTarget = inputObj.id ? inputObj.id : inputObj.name;
        if (forTarget) {
            label = document.querySelectorAll('label[for=' + forTarget + ']')[0];
        }
        return label;
    };

}
/**
 * Controls the apparition of the overlay menu
 */
function HM_OverlayMenu() {
    this.handlerAttribute = 'data-handler-for-menu';
    this.menuOpenedClass = 'is--open';
    this.menuFromBottomClass = 'is--from-bottom';

    this.onInit = function (applyTo) {
        var self = this;

        [].forEach.call(applyTo, function (menuHandler) {
            var menuId = menuHandler.attributes[self.handlerAttribute].value,
        		menu = menuId ? document.getElementById(menuId) : null;

            if (menu) {
                self.bindEvents(menuHandler, menu);
            }
        });
    };

    /**
     * binds click event for handler: overlay menu toggle
     * @param  HTMLElement handler
     * @param  HTMLElement menu
     */
    this.bindEvents = function (handler, menu) {
        var self = this;

        handler.addEventListener('click', function (e) {
            e.preventDefault();
            self.toggle(menu, handler);
        });

        handler.addEventListener('blur', function () {
            self.hideIfBlurOutside(menu, handler);
        });

        [].forEach.call(menu.querySelectorAll('a'), function (menuLink) {
            menuLink.addEventListener('blur', function () {
                self.hideIfBlurOutside(menu, handler);
            });
        });
    };

    /**
     * opens the menu
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     */
    this.open = function (menu, handler) {
        this.positionMenu(menu, handler);
        menu.classList.add(this.menuOpenedClass);
        menu.setAttribute('aria-expanded', true);
    };

    /**
     * closes the menu
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     */
    this.close = function (menu, handler) {
        menu.classList.remove(this.menuOpenedClass);
        menu.setAttribute('aria-expanded', false);
    };

    /**
     * open or close the menu
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     */
    this.toggle = function (menu, handler) {
        this.positionMenu(menu, handler);
        menu.setAttribute('aria-expanded', menu.classList.toggle(this.menuOpenedClass));
    };

    /**
     * set the position for the menu based on handler position
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     */
    this.positionMenu = function (menu, handler) {
        var handlerRect = handler.getBoundingClientRect(),
            top = handlerRect.top + handler.offsetHeight,
    		left = handlerRect.left;

        menu.style.transitionDuration = '0s';

        menu.style.top = (window.scrollY + top) + 'px';
        menu.style.left = (window.scrollX + left) + 'px';


        if (this.isOutOfBounds('vertical', menu)) {
            top = handlerRect.top - menu.offsetHeight;
            menu.style.top = (window.scrollY + top) + 'px';
            menu.classList.add(this.menuFromBottomClass);
        } else {
            menu.classList.remove(this.menuFromBottomClass);
        }

        if (this.isOutOfBounds('horizontal', menu)) {
            left = handlerRect.left + handler.offsetWidth - menu.offsetWidth;
            menu.style.left = (window.scrollX + left) + 'px';
        }

        menu.style.transitionDuration = '';
    };

    /**
     * tells if the menu is out of the screen bounds
     * @param  String  direction 	vertical/horizontal
     * @param  HTMLElement menu
     * @return {Boolean}           is out of bounds
     */
    this.isOutOfBounds = function (direction, menu) {
        var menuRect = menu.getBoundingClientRect(),
    		isOut = false,
    		upperSpace,
    		lowerSpace;

        if (direction === 'vertical') {
            upperSpace = menuRect.top;
            lowerSpace = window.innerHeight - menuRect.top;

            isOut = (menuRect.bottom > window.innerHeight) && (upperSpace > lowerSpace);
        }

        if (direction === 'horizontal') {
            isOut = menuRect.right > window.innerWidth;
        }

        return isOut;
    };

    /**
     * Hides the menu if the user clicks outside
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     */
    this.hideIfBlurOutside = function (menu, handler) {
        var self = this;

        if (menu.classList.contains(this.menuOpenedClass)) {
            // firefox & IE don't refresh "document.activeElement" on blur, so a little delay is the only
            // way to tell if the field is losing focus inside the list or outside
            window.setTimeout(function () {
                if (self.isBlurTargetOutside(document.activeElement, menu, handler)) {
                    self.close(menu, handler);
                }
            }, 1);
        }
    };

    /**
     * checks if target element is outside the menu/handler
     * @param  HTMLElement target
     * @param  HTMLElement menu
     * @param  HTMLElement handler
     * @return {Boolean}         true if target is outside
     */
    this.isBlurTargetOutside = function (target, menu, handler) {
        var targetGrandParent = target.parentElement;

        if (targetGrandParent) {
            targetGrandParent = targetGrandParent.parentElement;
        }

        return ((target !== handler) && (targetGrandParent !== menu));
    };

}
/**
 * Sidebar component collapse and height handlers
 */
function HM_Sidebar () {
    this.sidebarClass = '{root}{component}sidebar';
    this.isOverflow = '{js-hooks}overflow';
    this.isMinified = '{js-hooks}minified';

    this.onInit = function () {
        var self = this;
        self.isOverflow = HammeriteJS.replaceWithPrefixes(self.isOverflow);
        self.sidebarClass = HammeriteJS.replaceWithPrefixes(self.sidebarClass);
        self.isMinified = HammeriteJS.replaceWithPrefixes(self.isMinified);

        document.querySelector('.' + self.sidebarClass + '__header-toggle').addEventListener('click', function (e) {
            [].map.call(document.querySelectorAll('.' + self.sidebarClass), function (el) {
                el.classList.toggle(self.isMinified);
            });
        });

        self.findWrapper().style.height = self.getHeight() + 'px';

        if (self.findSidenav().offsetHeight > self.findWrapper().offsetHeight) {
            self.findWrapper().classList.add(self.isOverflow);
        }
    };

    this.findSidenav = function () {
        var nav;

        nav = document.getElementsByClassName(this.sidebarClass + '__nav');

        return nav[0];
    };

    this.findWrapper = function () {
        var wrapper;

        wrapper = document.getElementsByClassName(this.sidebarClass + '__wrapper');

        return wrapper[0];
    };

    this.getHeight = function () {
        var totalHeight,
            getTotalHeight,
            getFooter = document.getElementsByClassName(this.sidebarClass + '__footer'),
            getHeader = document.getElementsByClassName(this.sidebarClass + '__header');

        getTotalHeight = document.documentElement.clientHeight;

        totalHeight = getTotalHeight - (getFooter[0].offsetHeight + getHeader[0].offsetHeight);

        return totalHeight;
    };
}
/**
 * Highlights the row and column headers when editing a editable table cell
 */
function HM_EditableTableFocus() {

    this.activeEditionClassName = 'is--edition-active';

    this.onInit = function (tableInputs) {
        var self = this;

        tableInputs.forEach(function (tableInput) {
            tableInput.addEventListener('focus', function () {
                self.findMyColumnHead(this).classList.add(self.activeEditionClassName);
                self.findMyRow(this).classList.add(self.activeEditionClassName);
            });

            tableInput.addEventListener('blur', function () {
                self.findMyColumnHead(this).classList.remove(self.activeEditionClassName);
                self.findMyRow(this).classList.remove(self.activeEditionClassName);
            });
        });
    };

    this.findMyColumnHead = function (tableInput) {
        var myCellIndex = tableInput.parentElement.cellIndex;
        return this.findParentOfType(tableInput, 'table').querySelectorAll('th')[myCellIndex];
    };

    this.findMyRow = function (tableInput) {
        return this.findParentOfType(tableInput, 'tr');
    };

    this.findParentOfType = function (element, nodeType) {
        while (element && (element.tagName.toLowerCase() !== nodeType.toLowerCase())) {
            element = element.parentElement;
        }
        return element;
    };
}
/**
 * Fixed tabs swipe handler
 */
function HM_TabsSwipe() {
    /**
     * max width for swipe scroll in pixels
     * @type String
     */
    this.swipeBreakPoint = '640px';
    this.allContainers = [];

    this.onInit = function (tabContainers) {
        this.allContainers = tabContainers;
        this.allContainers.forEach(function (tabContainer) {
            tabContainer.swipeScroll = new HM_swipeScroll();
            tabContainer.swipeScroll.init(tabContainer);
        });

        this.apply();
     };

     this.onResize = function () {
        this.apply();
     };

    this.apply = function () {
        var self = this;

        this.allContainers.forEach(function (tabContainer) {
            if (window.matchMedia('(max-width: ' + self.swipeBreakPoint + ')').matches) {
                tabContainer.swipeScroll.apply();
            } else {
                tabContainer.swipeScroll.remove();
            }
        });
    };
}



var HM_swipeScroll = function () {
    return {

        /* ===== Constants ===== */

        /**
         * class to add when the container needs scroll
         * @type String
         */
        overflowClass: '{component}tabs--with-scroll',

        /**
         * class to add when the container IS scrolling
         * @type String
         */
        scrollingClass: '{component}tabs--scrolling',

        /**
         * Class name for gradients overlay
         * @type String
         */
        gradientOverlayClass: '{component}tabs__scroll-overlay',
        /**
         * Apply swipe scroll from # of tabs
         * @type Number
         */
        addScrollFrom: 3,

        /**
         * Show part of the next tab (%)
         * @type Number
         */
        visiblePartPercent: 50,

        /**
         * Tab bar swipe margins (%)
         * @type Number
         */
        dragMarginsPercent: 40,

        /**
         * Minimum offset for swipe (px)
         * @type Number
         */
        swipeMinOffset: 15,

        /**
         * Swipe inertia (high values -> more inertia)
         * @type Number
         */
        inertiaFactor: 0.2,

        /* ===== Properties ===== */
        container: null,
        gradientOverlay: {
            container: null,
            left: null,
            right: null
        },

        n: 0,
        tabWidth: 0,
        dragMargins: 0,
        allowSwipe: false,

        position: 0,

        touch: {
            isSwipe: false,
            started: false,
            startPoint: null,
            diff: null,
            last: null,
            speed: null
        },

        /* ===== Methods ===== */

        /**
         * Initializes a container element
         * @param  DOMelement container
         */
        init: function (container) {
            this.overflowClass = HammeriteJS.replaceWithPrefixes(this.overflowClass);
            this.scrollingClass = HammeriteJS.replaceWithPrefixes(this.scrollingClass);
            this.gradientOverlayClass = HammeriteJS.replaceWithPrefixes(this.gradientOverlayClass);

            this.container = container;
            this.n = container.querySelectorAll('li').length;

            this.createOverlayGradients();
            this.bindSwipeEventListeners();
            this.bindTabEvents();
        },

        /**
         * Applies the swipe behaviour to the container if it has a number
         * of child tabs over the limit
         */
        apply: function () {
            if (this.n > this.addScrollFrom) {
                this.position = 0;
                this.container.style.width = this.containerWidth() + '%';
                this.tabWidth = this.container.querySelector('li').offsetWidth;
                this.dragMargins =  Math.ceil( this.tabWidth * (this.dragMarginsPercent / 100));
                this.container.style.padding = '0 ' + this.dragMargins + 'px';
                this.container.style.transform = 'translateX(-' + this.dragMargins + 'px)';
                this.container.classList.add(this.overflowClass);
                this.container.classList.add(this.scrollingClass);
                this.moveOverlayGradients(this.dragMargins);
                this.allowSwipe = true;
            }
        },

        /**
         * Removes the swipe behaviour
         */
        remove: function () {
            this.container.classList.remove(this.overflowClass);
            this.container.style.width = '';
            this.container.style.padding = '';
            this.container.style.transform = 'translateX(0)';
            this.allowSwipe = false;
        },

        /**
         * Calculates the container width percent
         * @return Number container width percent
         */
        containerWidth: function () {
           var visibleTabs = this.addScrollFrom + this.visiblePartPercent / 100,
               tabWidthPercent = 100 / visibleTabs;

            return tabWidthPercent * this.n;
        },

        /**
         * Add the new DOM elements for the gradient overlays
         */
        createOverlayGradients: function () {
            this.gradientOverlay.container = this.createElementWithClass('div', this.gradientOverlayClass);
            this.gradientOverlay.left = this.createElementWithClass('span', this.gradientOverlayClass + '__left');
            this.gradientOverlay.right = this.createElementWithClass('span', this.gradientOverlayClass + '__right');

            this.gradientOverlay.container.appendChild(this.gradientOverlay.left);
            this.gradientOverlay.container.appendChild(this.gradientOverlay.right);
            this.container.appendChild(this.gradientOverlay.container);
        },

        /**
         * Create an element with a CSS class
         * @param  string elementType HTML tag name
         * @param  string className   CSS class name
         * @return DOMelement
         */
        createElementWithClass: function (elementType, className) {
            var element = document.createElement(elementType);
            element.className = className;
            return element;
        },

        /**
         * Translate the gradient overlay
         * @param  Number offset
         */
        moveOverlayGradients: function(offset) {
            var showLeftMin = this.dragMargins,
                showRightMin = this.container.offsetWidth - document.body.clientWidth - this.dragMargins,
                showClass = 'show';

            this.gradientOverlay.container.style.transform = 'translateX(' + offset + 'px)';

            this.addOrRemoveClass(offset > showLeftMin, this.gradientOverlay.left, showClass);
            this.addOrRemoveClass(offset < showRightMin, this.gradientOverlay.right, showClass);
        },

        /**
         * Adds or removes a CSS class using a condition
         * @param bool          addOrRemove condition
         * @param DOMelement    element     DOM element
         * @param string        className   CSS class
         */
        addOrRemoveClass: function (addOrRemove, element, className) {
            if (addOrRemove) {
                element.classList.add(className);
            } else {
                element.classList.remove(className);
            }
        },

        /**
         * Binds the swipe event listeners to the container
         */
        bindSwipeEventListeners: function () {
            var me = this;

            this.bindEvents(['touchstart','MSPointerDown'], function (e) {
                if (me.allowSwipe) {
                    me.startTouchListener(e);
                }
            });
            this.bindEvents(['touchmove', 'MSPointerMove'], function (e) {
                if (me.allowSwipe) {
                    me.moveTouchListener(e);
                }
            });
            this.bindEvents(['touchend', 'MSPointerUp'], function (e) {
                if (me.allowSwipe) {
                    me.endTouchListener(e);
                }
            });

            // avoid drag action for MS devices
            this.container.addEventListener('dragstart', function(e) {
                e.preventDefault();
                return false;
            }, false);
         },

         /**
          * Bind events for tabs
          */
         bindTabEvents: function () {
            var self = this,
                allTabs = this.container.querySelectorAll('a'),
                n = 0,
                listener;

            listener = function (e) {
                if (self.allowSwipe) {
                    self.centerTo(this.swipeIndex);
                }
            };

            for (n = 0; n < allTabs.length; n++) {
                allTabs[n].swipeIndex = n;
                allTabs[n].addEventListener('click', listener, false);
                allTabs[n].addEventListener('focus', listener, false);
            }
         },

         /**
          * Bind severals events with the same listener
          * @param  array       events      event names array
          * @param  function    listener    listener function
          */
         bindEvents: function (events, listener) {
            for(var event in events) {
                this.container.addEventListener(events[event], listener, false);
            }
         },

         /**
          * Listener for swipe start
          * @param  object e event
          */
         startTouchListener: function (e) {
            this.container.classList.add(this.scrollingClass);
            this.touch.last = this.touch.startPoint = this.getTouchX(e);
            this.touch.isSwipe = false;
            this.touch.started = true;
         },

         /**
          * Listener for swipe move
          * @param  object e event
          */
         moveTouchListener: function (e) {
            if (this.touch.started) {
                var touchX = this.getTouchX(e);

                this.touch.diff = this.touch.startPoint - touchX;
                this.touch.speed = this.touch.last - touchX;
                this.touch.last = touchX;

                if ((Math.abs(this.touch.diff) > this.swipeMinOffset) || this.touch.isSwipe) {
                    this.move(this.touch.diff, false);
                    this.touch.isSwipe = true;
                }
            }
         },

         /**
          * Listener for swipe end
          * @param  object e event
          */
         endTouchListener: function () {
            this.container.classList.remove(this.scrollingClass);
            if (this.touch.isSwipe) {
                this.move(this.touch.diff, true);
            }
            this.touch.started = false;
         },

         /**
          * returns touch X position
          * @param  object  e   browser event object
          * @return Number      X position
          */
         getTouchX: function (e) {
            if (e.touches) {
                return e.touches[0].clientX;
            } else {
                return e.clientX;
            }
         },

         /**
          * Moves the container relative to its current position
          * @param  number      offset
          * @param  bool        release     tells if the swipe is ending
          */
         move: function (offset, release) {
            var newPosition,
                speedOffset = 0;

            if (!release) {
                newPosition = this.limit(this.position - offset, true);
            } else {
                speedOffset = Math.ceil((this.touch.speed - 1) * this.tabWidth * this.inertiaFactor);
                newPosition = this.position = this.adjustToTab(this.position - offset - speedOffset);
            }

            this.translateContainer(newPosition, false);
         },

         /**
          * Returns a position into the container bounds
          * @param  Number      position    new position
          * @param  bool        addMargins  take the drag margins into account
          * @return Number                  position into the bounds
          */
         limit: function (position, addMargins) {
            var margins = addMargins ? 0 : this.dragMargins,
                upper = -margins,
                lower = - this.container.offsetWidth + document.body.clientWidth + margins;

            if (position > upper) {
                position = upper;
            } else if (position < lower) {
                position = lower;
            }
            return position;
         },

         /**
          * Moves the container to a new position
          * @param  number      position        new position
          * @param  bool        fixPosition     set the new position as current
          */
         translateContainer: function (position, fixPosition) {
            this.container.style.transform = 'translateX(' + position + 'px)';
            this.moveOverlayGradients(-position);

            if (fixPosition) {
                this.position = position;
            }
        },

         /**
          * returns a position adjusted to any tab begin position
          * @param  Number      position    new position
          * @return Number                  position according to the tabs positions
          */
         adjustToTab: function (position) {
            var index = Math.round((position + this.dragMargins) / this.tabWidth);

            return this.limit(index * this.tabWidth - this.dragMargins, false);
         },

         /**
          * Centers the tab tar in tab #index
          * @param  Number index tab number (0,1,...)
          */
         centerTo: function (index) {
            var position = this.tabWidth * index;

            position += Math.floor(this.tabWidth / 2) + 1;
            position += this.dragMargins;
            position -= Math.floor(document.body.clientWidth / 2);
            this.container.classList.remove(this.scrollingClass);
            this.translateContainer(this.adjustToTab(-position), true);
         }
    };
};
/**
 * Active tab logic
 */
function HM_Tabs() {
	this.tabClass = '{root}{component}tabs__tab';
    this.activeTabBarClass = this.tabClass + '-active-bar';
	this.activeClass = 'is--active';
    this.containers = [];

   	this.onInit = function (applyTo) {
        var self = this;

        self.tabClass = HammeriteJS.replaceWithPrefixes(self.tabClass);
        self.activeTabBarClass = HammeriteJS.replaceWithPrefixes(self.activeTabBarClass);

        self.containers = applyTo;

        [].forEach.call(self.containers, function (tabContainer) {
            self.createActiveTabBar(tabContainer);
            self.bindTabsListenersToContainer(tabContainer);
            self.setFirstTabActiveInto(tabContainer);
        });
    };

    this.onResize = function () {
        var self = this;

        [].forEach.call(self.containers, function (tabContainer) {
            self.resizeActiveBar(tabContainer);
        });
    };

    /**
     * creates a new DOM element for the active tab indicator inside the first tab
     * @param  HTMLElement  tabContainer
     */
    this.createActiveTabBar = function (tabContainer) {
        var newDOMelement = document.createElement('div');

        newDOMelement.classList.add(this.activeTabBarClass);
        this.getFirstTab(tabContainer).appendChild(newDOMelement);
    };

    /**
     * Attach the click listener to all the links inside tabContainer
     * @param  HTMLElement 	tabContainer
     */
    this.bindTabsListenersToContainer = function (tabContainer) {
        var self = this,
            tabs = tabContainer.querySelectorAll('.' + this.tabClass);

         [].forEach.call(tabs, function (tab) {
            self.listenClassChange(tabContainer, tab);
            self.listenAnchorClick(tabContainer, tab);
         });
    };

    /**
     * adds a listener to 'tab' in order to detect class changes
     * @param  HTMLElement tabContainer
     * @param  HTMLElement tab
     */
    this.listenClassChange = function (tabContainer, tab) {
        var self = this;

        tab.classChangeObserver = new MutationObserver(function (changeRecords) {
            self.grantActiveListener(tabContainer, changeRecords);
        });

        tab.classChangeObserver.observe(tab, { attributes: true, attributeOldValue: true, attributeFilter: ['class'] });
    };

    /**
     * listen to 'active' class grant. It's needed to be performed this way in case the 'active' is granted using
     * another script.
     * @param  changeRecords   Observer change records
     */
    this.grantActiveListener = function (tabContainer, changeRecords) {
        var self = this;

        changeRecords.forEach(function (record) {
            var newClass = record.target.attributes['class'].value;

            if (newClass.indexOf(self.activeClass) !== -1) {
                self.moveActiveBarTo(tabContainer, record.target);
            }
        });
    };

    /**
     * Adds click listener to tab anchor
     * @param  HTMLElement tabContainer
     * @param  HTMLElement tab
     */
    this.listenAnchorClick = function (tabContainer, tab) {
        var self = this;

         tab.querySelector('a').addEventListener('click', function(e) {
            e.preventDefault();
            self.moveActiveTo(tab, tabContainer);
            return false;
        }, false);
    };

    /**
     * translate the 'active bar' to the new active tab
     * @param  HTMLElement tab
     */
    this.moveActiveBarTo = function (tabContainer, tab) {
        var tabOffset = tab.offsetLeft,
            tabWidth = tab.offsetWidth,
            firstTab = tabContainer.querySelector('.' + this.tabClass),
            firstTabOffset = firstTab.offsetLeft;

        this.updateActiveBar(tabContainer, tabOffset - firstTabOffset, tabWidth);
    };

    /**
     * update active bar properties
     * @param  HTMLElement  tabContainer
     * @param  integer      offset
     * @param  integer      width
     */
    this.updateActiveBar = function (tabContainer, offset, width) {
        var activeTabBar = tabContainer.querySelector('.' + this.activeTabBarClass);

        activeTabBar.setAttribute('style', 'transform: translateX(' + offset + 'px); width: ' + width + 'px;');
    };

    /**
     * resizes the active bar
     * @param  HTMLElement  tabContainer
     */
    this.resizeActiveBar = function (tabContainer) {
        this.moveActiveBarTo(tabContainer, this.getActiveTab(tabContainer));
    };

    /**
     * Grant 'active' to the first tab
     * @param  HTMLElement 	tabContainer
     */
    this.setFirstTabActiveInto = function (tabContainer) {
		if (this.getActiveTab(tabContainer) === null) {
			tabContainer.querySelector('.' + this.tabClass).classList.add(this.activeClass);
		}
    };

    /**
     * Returns the active tab
     * @param  HTMLElement 	tabContainer
     * @return HTMLElement            		Active tab
     */
    this.getActiveTab = function (tabContainer) {
    	return tabContainer.querySelector('.' + this.tabClass + '.' + this.activeClass);
    };

    /**
     * returns the first tab inside a tab container
     * @param  HTMLElement  tabContainer
     * @return HTMLElement                  First tab
     */
    this.getFirstTab = function (tabContainer) {
        return tabContainer.querySelector('.' + this.tabClass);
    };

    /**
     * Removes 'active' class to the current active tab, and set it to the
     * new active tab
     * @param  HTMLElement 	anchor       New active tab
     * @param  HTMLElement 	tabContainer
     */
    this.moveActiveTo = function (anchor, tabContainer) {
    	var currentActive = this.getActiveTab(tabContainer);

    	if (currentActive !== null) {
    		currentActive.classList.remove(this.activeClass);
    	}

    	anchor.classList.add(this.activeClass);
    };

}
/**
 * Adjust the textarea height dynamically if 'auto-resize' attribute is present
 */
function HM_TextareaAutoheight () {

    this.isMSIE = 0;
    this.allTextareas = [];
    this.eventsBinded = false;

    this.onInit = function (textareas) {
        this.allTextareas = textareas;
        this.detectMSIE();
        this.addCSS();
        this.adjustAll();
    };

    this.onResize = function () {
        this.adjustAll();
    };

    this.bindEvents = function (node) {
        var self = this,
            listener = function () {
                self.adjust(this);
            };

        // user input, copy, paste, cut occurrences
        node.addEventListener('input', listener, false);
        node.addEventListener('change', listener, false);
    };

    this.detectMSIE = function () {
        this.isMSIE = +((/msie (\d+)/.exec(navigator.userAgent.toLowerCase()) || [])[1]);

        if (isNaN(this.isMSIE)) {
            this.isMSIE = +((/trident\/.*; rv:(\d+)/.exec(navigator.userAgent.toLowerCase()) || [])[1]);
        }
    };

    this.adjustAll = function () {
        var self = this;

        [].forEach.call(this.allTextareas, function (textarea) {
            self.adjust(textarea);
            if (!self.eventsBinded) {
                self.bindEvents(textarea);
            }
        });

        this.eventsBinded = true;
    };

    this.adjust = function (node) {
        var lineHeight = this.getLineHeight(node);

        if (!(node.offsetHeight || node.offsetWidth)) {
            return;
        }

        if (node.scrollHeight <= node.clientHeight) {
            node.style.height = '0px';
        }

        var h = node.scrollHeight + // actual height defined by content
                node.offsetHeight - // border size compensation
                node.clientHeight; //       -- || --

        node.style.height = Math.max(h, lineHeight) +
                    (this.isMSIE && lineHeight ? lineHeight : 0) + // ie extra row
                    'px';
    };

    this.addCSS = function () {
        var style = document.createElement('style');
        style.innerHTML = '[auto-resize] {overflow: hidden; resize: none; box-sizing: border-box;}';
        document.head.appendChild(style);
    };

    this.getLineHeight = function (node) {
        var computedStyle = window.getComputedStyle(node),
            lineHeightStyle = computedStyle.lineHeight;

        if (lineHeightStyle === 'normal') {
            return +computedStyle.fontSize.slice(0, -2);
        } else {
            return +lineHeightStyle.slice(0, -2);
        }
    };

}
/**
 * Adds a counter to a textarea if 'data-maxchars' is present
 */
function HM_TextareaCounter () {

    this.counterClass = '{root}{object}text-count';

    this.onInit = function (textareas) {
        var self = this;
        self.counterClass = HammeriteJS.replaceWithPrefixes(self.counterClass);

        [].forEach.call(textareas, function (textarea) {
            if (textarea.getAttribute('data-maxchars') !== null) {
                self.attachRelatedElements(textarea);
                self.updateCounter(textarea);
                self.bindEvents(textarea);
            }
        });
    };

    this.bindEvents = function (textarea) {
        var self = this,
            listener = function () {
                self.updateCounter(textarea);
            };

        textarea.addEventListener('input', listener, false);
        textarea.addEventListener('change', listener, false);
    };

    this.attachRelatedElements = function (textarea) {
        textarea.counter = textarea.parentElement.nextElementSibling;
        textarea.textAreaLabel = document.querySelector('label[for="' + textarea.id + '"]');
    };

    this.updateCounter = function (textarea) {
        var maxchars = textarea.getAttribute('data-maxchars'),
            charsCount = textarea.value.length;

        if (textarea.counter.classList.contains(this.counterClass)) {
            // Update value
            textarea.counter.innerHTML = (maxchars - charsCount) + "/" + maxchars + " characters";

            // Set styles
            if (charsCount > maxchars) {
                // Exceeding max
                this.setStylesForLimitExceeded(textarea);
            } else if ((maxchars - charsCount) <= 20 & (maxchars - charsCount) >= 0) {
                // Approaching max
                this.setStylesForLimitApproaching(textarea);

            } else {
                // Safe range
                this.setStylesForLimitDefault(textarea);
            }
        }
    };

    this.setStylesForLimitExceeded = function (textarea) {
        this.removeAllClasses(textarea);
        this.addClassIfNotExists(textarea.counter, this.counterClass + '--wrong');
        this.addClassIfNotExists(textarea, 'is-error');
        this.addClassIfNotExists(textarea.textAreaLabel, 'is-error');
        textarea.validity.tooLong = true;
    };

    this.setStylesForLimitApproaching = function (textarea) {
        this.removeAllClasses(textarea);
        this.addClassIfNotExists(textarea.counter, this.counterClass + '--warning');
        this.addClassIfNotExists(textarea, 'is-warning');
        this.addClassIfNotExists(textarea.textAreaLabel, 'is-warning');

        textarea.validity.tooLong = false;
    };

    this.setStylesForLimitDefault = function (textarea) {
        this.removeAllClasses(textarea);
        textarea.validity.tooLong = false;
    };

    this.removeAllClasses = function (textarea) {
        this.removeClassIfExists(textarea.counter, this.counterClass + '--warning');
        this.removeClassIfExists(textarea.counter, this.counterClass + '--wrong');
        this.removeClassIfExists(textarea.textAreaLabel, 'is-warning');
        this.removeClassIfExists(textarea.textAreaLabel, 'is-error');
        this.removeClassIfExists(textarea, 'is-error');
        this.removeClassIfExists(textarea, 'is-warning');
    };

    this.addClassIfNotExists = function (node, className) {
        !node.classList.contains(className) ? node.classList.add(className) : "";
    };

    this.removeClassIfExists = function (node, className) {
        node.classList.contains(className) ? node.classList.remove(className) : "";
    };
}
/**
 * Toggle topbar search field
 */
function HM_TopbarSearch() {
    this.extendedSearchClass = 'is--search-expanded';
    this.toggleHandler = '.{root}{component}topbar__search .{root}{component}topbar__link';
    this.titleClass = '.{root}{component}topbar__link-title';

    this.onInit = function (applyTo) {
        var self = this;

        this.toggleHandler = HammeriteJS.replaceWithPrefixes(this.toggleHandler);
        this.titleClass = HammeriteJS.replaceWithPrefixes(this.titleClass);

        [].forEach.call(applyTo, function (topBarToolBar) {
        	var searchHandler = topBarToolBar.querySelector(self.toggleHandler);
			searchHandler.parentToolbar = topBarToolBar;

        	if (searchHandler) {
				searchHandler.addEventListener('click', function (e) {
    				e.preventDefault();
        			self.toggleSearchExpand(searchHandler, topBarToolBar);
        		});
        	}
        });
    };

    /**
     * expands or collapses the search input
     * @param  HTMLElement searchHandler
     * @param  HTMLElement topBarToolBar
     */
    this.toggleSearchExpand = function (searchHandler, topBarToolBar) {
		if (!this.isSearchExpanded(searchHandler)) {
			this.resetItemsWidth(topBarToolBar);
			this.setFixedWidthToItems(topBarToolBar);
			this.focusSearchInput(searchHandler);
		}

		searchHandler.parentToolbar.classList.toggle(this.extendedSearchClass);
    };

    /**
     * checks if seach input is expanded
     * @param  HTMLElement searchHandler
     * @return {Boolean}
     */
    this.isSearchExpanded = function (searchHandler) {
    	return searchHandler.parentToolbar.classList.contains(this.extendedSearchClass);
    };

    /**
     * topbar items width needs to be fixed (not auto) for css transition
     * @param  HTMLElement topBarToolBar
     */
    this.setFixedWidthToItems = function (topBarToolBar) {
    	this.setWidthForAllTitles(topBarToolBar, function (title) {
    		return title.offsetWidth + 'px';
    	});
    };

    /**
     * removes the fixed width from topbar items
     * @param  HTMLElement topBarToolBar
     */
    this.resetItemsWidth = function (topBarToolBar) {
    	this.setWidthForAllTitles(topBarToolBar, function (title) {
    		return '';
    	});
    };

    /**
     * sets style="width: ..." for all toolbar titles
     * @param  {[type]} topBarToolBar [description]
     * @param  {[type]} styleCallBack [description]
     * @return {[type]}               [description]
     */
    this.setWidthForAllTitles = function (topBarToolBar, widthCallBack) {
    	var titles = topBarToolBar.querySelectorAll(this.titleClass);

    	[].forEach.call(titles, function (title) {
    		title.style.width = widthCallBack(title);
    	});
    };

    /**
     * focuses the seach input
     * @param  HTMLElement searchHandler
     */
    this.focusSearchInput = function (searchHandler) {
    	var inputElement = searchHandler.nextElementSibling.parentElement.querySelector('input');

    	if (inputElement) {
    		inputElement.focus();
    	}
    };
}